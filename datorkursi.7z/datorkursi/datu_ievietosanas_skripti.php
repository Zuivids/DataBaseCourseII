<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Datu ievietošanas skripti</title>
    <link rel="stylesheet" href="mystyle.css">
</head>
<body>
<button><a href="datorkursi.html">Atpakaļ</a></button>
<h1 id="saraksts">Datu ievietošanas skripti</h1>
<?php
require_once("config.php");
$sql="show tables";
$result=$conn->query($sql);

$i=1;
while ($row= $result->fetch_assoc()){ 
  echo $i.'. &nbsp;<a class="saraksts" href="#id'.$i.'">'.$row["Tables_in_asins_donoru_centrs_parventa"].'</a><br>';  $i++;     
}

?>

<h3 id="id1">Arsti</h3>
<pre>INSERT INTO `arsti` VALUES (1,'Jānis','Bērziņš','190779-10506'),
  (2,'Valdis','Slišāns','200189-14329'),
  (3,'Jana','Bērzlape','090375-19345'),
  (4,'Inta','Niedre','150769-47923');</pre>
  <p><a href="#saraksts">Uz tabulu sarakstu</a></p>
<h3 id="id2">Asins nodosanas saraksts</h3>
<pre>INSERT INTO `asins_nodosanas_saraksts` VALUES (1,1,1,1,1,0),
  (2,2,2,1,2,0),
  (3,3,3,2,2,0),
  (4,4,4,2,2,0),
  (5,5,1,2,3,0),
  (6,6,2,2,3,0),
  (7,7,3,3,3,0),
  (8,8,4,3,4,0),
  (9,9,1,3,4,0),
  (10,10,4,4,4,0),
  (11,11,2,4,5,0),
  (12,12,3,4,5,0),
  (13,13,2,4,5,0),
  (14,14,2,4,3,0),
  (15,15,3,3,6,0),
  (16,16,1,3,6,0),
  (17,17,1,3,6,0),
  (18,18,1,3,7,0),
  (19,19,4,2,7,0),
  (20,20,4,2,7,0),
  (21,21,3,2,8,0),
  (22,22,3,2,8,0),
  (23,23,3,1,8,0),
  (24,24,2,1,8,0),
  (25,25,2,1,1,0),
  (26,26,2,1,1,0),
  (27,27,2,2,1,0),
  (28,28,1,2,1,0),
  (29,29,2,1,2,0),
  (30,30,1,1,2,0),
  (31,31,3,2,2,0),
  (32,32,3,2,3,0),
  (33,33,3,2,3,0),
  (34,34,2,2,3,0),
  (35,35,4,3,4,0),
  (36,36,4,3,4,0),
  (37,37,4,3,4,0),
  (38,38,4,4,5,0),
  (39,39,2,4,6,0),
  (40,40,2,2,7,0),
  (41,41,2,2,8,0),
  (42,13,1,1,5,0),
  (43,4,3,2,2,0),
  (44,15,2,3,6,0),
  (45,6,4,4,3,0),
  (46,17,4,4,6,0),
  (47,19,2,2,7,0),
  (48,2,1,3,2,0),
  (49,3,3,1,2,0),
  (50,4,2,2,2,0),
  (51,17,3,3,6,0),
  (52,19,4,2,7,0),
  (53,41,2,1,8,0),
  (54,37,1,2,4,0),
  (55,25,4,2,1,0),
  (56,29,2,3,2,0),
  (57,22,3,1,8,0),
  (58,25,1,4,1,0),
  (59,15,3,4,6,0),
  (60,3,2,2,2,0),
  (61,5,4,3,3,0),
  (62,19,2,2,7,0),
  (63,22,2,2,8,0),
  (64,29,1,1,2,0),
  (65,30,3,2,2,0);</pre>
  <p><a href="#saraksts">Uz tabulu sarakstu</a></p>
<h3 id="id3">Asinsgrupas</h3>
<pre>INSERT INTO `asinsgrupas` VALUES (1,'0+'),
  (2,'0-'),
  (3,'A+'),
  (4,'A-'),
  (5,'B+'),
  (6,'B-'),
  (7,'AB+'),
  (8,'AB-');</pre>
  <p><a href="#saraksts">Uz tabulu sarakstu</a></p>
</body>
</html>