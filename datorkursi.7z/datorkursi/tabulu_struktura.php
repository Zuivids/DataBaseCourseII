<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tabulu struktura</title>
    <link rel="stylesheet" href="mystyle.css">
</head>
<body>
<button><a href="datorkursi.html">Atpakaļ</a></button>
<h1>DB Tabulu saraksts</h1>
<?php
require_once("config.php");

// $sql="show tables";
// $result=$conn->query($sql);

// $i=1;
// while ($row=$result->fetch_assoc()) {
//     echo $i.". &nbsp;".$row["Tables_in_asins_donoru_centrs_parventa"]."<br>";
//     $i++;
// }

//TODO select option 

$sql="show tables";
$result=$conn->query($sql);
if(empty($_POST["submitPoga"])){
echo '<div>Izvēlaties tabulu<span class=>*</span>:</div>';
echo '<form method="post">';
echo '<select name ="tabulas" required>';
echo '<option value="" hidden></option>';
while ($row=$result->fetch_assoc()) {
echo '<option value="'.$row["Tables_in_asins_donoru_centrs_parventa"].'">'.$row["Tables_in_asins_donoru_centrs_parventa"].'</option>';
}
echo '</select>';
echo ' &nbsp;&nbsp;<input type="submit" name="submitPoga" value="Apskatīt tabulas izveides skriptu">';
echo '</form>';
}
else{
    $tabula=$_POST["tabulas"];
    //echo"<br>Tabula= ".$tabula;
    //show create table arsti
    $sql="show create table ".$tabula;
    //echo "<br>sql= ".$sql;
    $result=$conn->query($sql);
    $row=$result->fetch_assoc();
    echo '<pre>'.$row["Create Table"].'</pre>';
    }

?>
</body>
</html>