<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Tabulu saraksts</title>
    <link rel="stylesheet" href="mystyle.css">
</head>
<body>
<button><a href="datorkursi.html">Atpakaļ</a></button>
<h1>DB Tabulu saraksts</h1>
<?php
require_once("config.php");

// $sql="select 2+2";
// $result=$conn->query($sql);
// $row= $result->fetch_assoc();
// echo "<br>Summa =".$row["2+2"];

//1. Izveidot vaicajuma tekstu
$sql="show tables";
// //2. Vaicajuma izpilde
// //echo $conn->query($sql);
$result=$conn->query($sql);
// //3. Izvadit rezultātu
//print_r($result);
// echo "<br>Datu tips: ".gettype($result);
//echo "<br>Tabula: ".$row["Tables_in_asins_donoru_centrs_parventa"];
$i=1;
while ($row=$result->fetch_assoc()) {
    echo $i.". &nbsp;".$row["Tables_in_asins_donoru_centrs_parventa"]."<br>";
    $i++;
}

?>
</body>
</html>