<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Page Title</title>
    <link rel="stylesheet" href="mystyle.css">
</head>
<body>

    <h1>My First Heading</h1>
    <p>My first paragraph.</p>
    <?php
    echo "<h2>Programmēšanas valoda PHP</h2>";
    $x=5;
    $y=10;
    echo "Summa = ".($x+$y);
    echo "<br>".$x." + ".$y." = ".($x+$y);
    ?>

</body>
</html>


